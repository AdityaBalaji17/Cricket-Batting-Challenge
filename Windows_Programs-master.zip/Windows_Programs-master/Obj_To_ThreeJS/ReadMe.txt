This is a step towards converting Obj files exported from various 3d Softwares to a THREE.JS compatible
JSON, version 3.1.

This is the very first release of the windows program, made in C# 2010.

This uses a libaray from : http://james.newtonking.com/json which helps convert data from string to JSON.

Steps to Use:
1) Download all the files in a folder.

2) Run Converter.exe.

3) Choose an obj file by clicking on "Get File" button.

4) Once data is parsed from obj, information appears in the lower bottom of the program.

5) Now, click on the "Save File" button to export to the same location where the source file you choose
was. The file will be suffixed with "_converted.js" string.

Sample ThreeJS Code:
loader.load( "objects/cone_Converted.js", function( geometry ) {
	var mat = new THREE.MeshLambertMaterial();
	var mesh = new THREE.Mesh( geometry, mat );
	geometry.computeFaceNormals();
	mesh.position.set(0, 0, 0);
	var s = 5;
	mesh.scale.set(s, s, s);
	scene.add(mesh);
});

Features:
Supports multiple meshes(but reads as one mesh only)


Comming soon:
1) Material Support
2) Scene export support
